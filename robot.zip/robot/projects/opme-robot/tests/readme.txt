Executar testes:

Para executar testes utilize o comando                              robot -d ../results  Login.robot
sendo o -d para indicar o caminho onde os logs serão inseridos 
seguido do nomo do arquivo de teste que você quer que seja executado


Executar testes dando um título a execução do teste                 robot -N "TESTES LOGIN" -d ../results  Login.robot
deve-se utilizar o parametro -N "titulo desejado"
essa tag deve vir antes do -d


Executar testes utilizando TAGs                                     robot -N "TESTES LOGIN" -d ../results -i checklist  Login.robot