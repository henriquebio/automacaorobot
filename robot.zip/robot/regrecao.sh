cd /home/henrique/robot/projects/opme-robot/tests
robot Login.robot 
